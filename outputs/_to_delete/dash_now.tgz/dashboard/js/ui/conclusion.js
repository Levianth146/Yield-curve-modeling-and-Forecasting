import { el } from "./kit.js";
import { t } from "../i18n.js";

const STATUS_CLS = {
  supported: "conclusion-supported",
  fragile: "conclusion-fragile",
  notSupported: "conclusion-not",
};

/**
 * @param {HTMLElement} host
 * @param {{ status: 'supported'|'fragile'|'notSupported', headline: string, body: string, lang?: string }} opts
 */
export function conclusion(host, { status, headline, body, lang = "vi" }) {
  const key =
    status === "supported" ? "statusSupported" :
    status === "notSupported" ? "statusNotSupported" :
    "statusFragile";
  const tipKey =
    status === "supported" ? "statusTipSupported" :
    status === "notSupported" ? "statusTipNotSupported" :
    "statusTipFragile";
  const cls = STATUS_CLS[status] || STATUS_CLS.fragile;
  host.innerHTML = "";
  const box = el("div", {
    class: `conclusion ${cls}`,
    "aria-live": "polite",
  },
    el("span", { class: "conclusion-badge", title: t(lang, tipKey) }, t(lang, key)),
    el("p", { class: "conclusion-headline", html: headline }),
    el("div", { class: "conclusion-body", html: body }),
  );
  host.append(box);
  return {
    update({ status: st, headline: h, body: b }) {
      if (st) {
        const k = st === "supported" ? "statusSupported" : st === "notSupported" ? "statusNotSupported" : "statusFragile";
        const tk = st === "supported" ? "statusTipSupported" : st === "notSupported" ? "statusTipNotSupported" : "statusTipFragile";
        box.className = `conclusion ${STATUS_CLS[st] || STATUS_CLS.fragile}`;
        const badge = box.querySelector(".conclusion-badge");
        badge.textContent = t(lang, k);
        badge.title = t(lang, tk);
      }
      if (h != null) box.querySelector(".conclusion-headline").innerHTML = h;
      if (b != null) box.querySelector(".conclusion-body").innerHTML = b;
    },
  };
}

/**
 * Page shell: eyebrow + H2 + conclusion in hero.
 * @returns {{ setConclusion, setTitle }}
 */
export function pageHero(host, { eyebrow, title, status, headline, body, lang }) {
  host.innerHTML = "";
  host.className = "hero";
  const eb = el("div", { class: "eyebrow" }, eyebrow);
  const h2 = el("h2", {}, title);
  const slot = el("div", { class: "conclusion-slot" });
  host.append(eb, h2, slot);
  const api = conclusion(slot, { status, headline, body, lang });
  return {
    setTitle(s) { h2.textContent = s; },
    setConclusion: api.update,
  };
}
