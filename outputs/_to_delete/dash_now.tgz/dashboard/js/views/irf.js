import { el, fmt, figure, figs, chips, slider, axisX, axisY, tip, drawer } from "../ui/kit.js";
import { pageHero } from "../ui/conclusion.js";
import { explainBox, methodDetails, resetLink, term } from "../ui/glossary.js";
import { t } from "../i18n.js";
import { reproducePython } from "../reproduce.js";

const VAR = { cpi_mom_ann: "CPI", fed_funds: "Fed Funds", level: "Level", slope: "Slope", curvature: "Curvature" };
const VCOL = { cpi_mom_ann: "var(--series-b)", fed_funds: "var(--series-level)", level: "var(--series-level)", slope: "var(--series-slope)", curvature: "var(--series-curv)" };
const PRESETS = [["cpi_fed_lsc", "CPI→Fed→L,S,C"], ["fed_cpi_lsc", "Fed→CPI→LSC"], ["cpi_fed_slc", "CPI→Fed→S,L,C"], ["lsc_cpi_fed", "LSC→CPI→Fed"], ["cpi_lsc_fed", "CPI→LSC→Fed"], ["fed_lsc_cpi", "Fed→LSC→CPI"]];
const LAGS = [["p2", "p=2"], ["p4", "p=4"], ["p6", "p=6"], ["p12", "p=12"], ["aic_port", "AIC+Portmanteau"], ["bic", "BIC"]];
const INFL = [["cpi_mom_ann_w2", "MoM ann. w2"], ["cpi_mom_ann_w0", "MoM ann. w0"], ["cpi_mom_ann_w5", "MoM ann. w5"], ["cpi_yoy", "YoY"]];
const I1 = [["adf", "ADF"], ["force_fed_slope", "Force Δ Fed & Slope"]];

const cellOf = (cfg, imp, res, h) => cfg.irf.find((r) => r.impulse === imp && r.response === res && r.h === h);

export async function mountIrf(ctx) {
  const { state, data, hero: heroEl, controls, viz, lang, persist, isDefaults, resetToDefaults } = ctx;
  const vi = lang !== "en", s = state.irf;
  const page = pageHero(heroEl, {
    eyebrow: vi ? "04 · RQ3 · VAR / IRF" : "04 · RQ3 · VAR / IRF",
    title: t(lang, "h2Irf"),
    status: "fragile",
    lang,
    headline: "…",
    body: "…",
  });
  viz.innerHTML = `<p class="spin">${vi ? "Đang tải lưới IRF…" : "Loading IRF grid…"}</p>`;
  const grid = await data.loadIrf();
  viz.innerHTML = "";
  if (!grid?.configs?.length) {
    viz.append(el("p", { class: "callout" }, vi ? "Chưa có irf_grid.json." : "irf_grid.json missing."));
    return;
  }
  const ok = grid.configs.filter((c) => c.irf && !c.error);
  const chg = () => { persist(); update(); };
  if (!s.lagMode) s.lagMode = "p4";

  const varOpts = Object.entries(VAR).map(([id, label]) => ({ id, label }));
  controls.append(
    chips({ label: vi ? "Cú sốc từ" : "Shock to", options: varOpts, value: s.impulse, onPick: (v) => { s.impulse = v; chg(); } }),
    chips({ label: vi ? "Phản ứng của" : "Response of", options: varOpts, value: s.response, onPick: (v) => { s.response = v; chg(); } }),
    slider({ label: vi ? "Độ lớn cú sốc" : "Shock size", min: 0.5, max: 3, step: 0.5, value: s.shock, format: (v) => v + "σ", onInput: (v) => { s.shock = v; chg(); } }),
    slider({ label: vi ? "Chân trời (tháng)" : "Horizon (months)", min: 1, max: 24, value: s.h, format: (v) => v + "M", onInput: (v) => { s.h = v; chg(); } }),
  );
  const specBox = el("div");
  const mk = (label, opts, key) => chips({ label, options: opts.map(([id, l]) => ({ id, label: l })), value: s[key], onPick: (v) => { s[key] = v; chg(); } });
  specBox.append(
    mk(vi ? "Thứ tự Cholesky" : "Cholesky order", PRESETS, "preset"),
    mk(vi ? "Số lag" : "Lags", LAGS, "lagMode"),
    mk(vi ? "Lạm phát" : "Inflation", INFL, "infl"),
    mk("I(1)", I1, "i1"),
  );
  controls.append(drawer(vi ? "Đặc tả mô hình (288 cấu hình)" : "Model specification (288 configs)", specBox));
  const rst = resetLink(lang, !isDefaults(), () => resetToDefaults());
  if (rst) controls.append(rst);

  const fPath = figure({ title: "​", sub: "", height: 300, margin: { r: 70 } });
  const fShock = figure({
    title: vi ? "Cú sốc là gì? (Fed → Fed)" : "What is the shock? (Fed → Fed)",
    sub: vi ? "Phản ứng của chính Fed funds trước cú sốc 1σ của nó." : "Fed funds response to its own 1σ shock.",
    height: 220, margin: { r: 20 },
  });
  const fSpec = figure({ title: "​", sub: "", height: 300, margin: { r: 20 } });
  const fMulti = el("div", { class: "figs five" });
  const captionBelow = el("p", { class: "fig-caption-below" });
  viz.append(figs("two", fPath.root, fShock.root), el("div", { style: "height:24px" }), fSpec.root, captionBelow, el("div", { style: "height:24px" }), el("h3", { class: "fig-title" }, vi ? "Cùng cú sốc, mọi biến phản ứng" : "Same shock, every response"), el("p", { class: "fig-sub" }, vi ? "Vùng tô: CI 95%. Ô đậm = đang xem." : "Band: 95% CI. Bold = selected."), fMulti);
  const T = tip();

  function pickCfg() {
    return ok.find((c) => c.preset === s.preset && c.lag_mode === (s.lagMode || "p4") && c.infl === s.infl && c.i1_mode === s.i1) || null;
  }

  function update() {
    const cfg = pickCfg(), K = Number(s.shock), h0 = Number(s.h);
    if (!cfg) {
      page.setConclusion({ status: "notSupported", headline: vi ? "Cấu hình này chưa được tính sẵn." : "This configuration is not precomputed.", body: "" });
      return;
    }
    const sig = cellOf(cfg, s.impulse, s.impulse, 0)?.irf || 1;
    const path = d3.range(0, 25).map((h) => cellOf(cfg, s.impulse, s.response, h)).filter(Boolean).map((c) => ({ h: c.h, v: c.irf * K, lo: c.lo * K, hi: c.hi * K }));
    const c0 = path.find((p) => p.h === h0);
    const strong = c0 && (c0.lo > 0 || c0.hi < 0);
    const port = cfg.portmanteau_p, portOk = port > 0.05;

    const pts = ok.map((c) => {
      const q = cellOf(c, s.impulse, s.response, h0);
      return q ? { v: q.irf * K, lo: q.lo * K, hi: q.hi * K, clean: c.stable && (c.portmanteau_p ?? 1) > 0.05, cur: c === cfg, c } : null;
    }).filter(Boolean).sort((a, b) => a.v - b.v);
    const pos = pts.filter((q) => q.lo > 0).length, neg = pts.filter((q) => q.hi < 0).length, mid = pts.length - pos - neg;
    const status = pos / pts.length >= 0.8 ? "supported" : "fragile";

    const delta = c0 ? fmt.yieldChange(c0.v) : "—";
    page.setConclusion({
      status,
      headline: vi
        ? (strong
          ? `Cú sốc Fed +${K}${term("sigma", lang).outerHTML} làm ${VAR[s.response]} ${c0.v > 0 ? "tăng" : "giảm"} <span class="num">${delta}</span> sau ${h0} tháng.`
          : `Cú sốc Fed +${K}${term("sigma", lang).outerHTML} không đổi ${VAR[s.response]} có ý nghĩa sau ${h0} tháng.`)
        : (strong
          ? `A Fed +${K}${term("sigma", lang).outerHTML} shock moves ${VAR[s.response]} by <span class="num">${delta}</span> after ${h0} months.`
          : `A Fed +${K}${term("sigma", lang).outerHTML} shock does not significantly move ${VAR[s.response]} after ${h0} months.`),
      body: c0 ? (vi
        ? `1σ ≈ <span class="num">${fmt.n(sig * 100, 1)} bp</span>. CI 95% [<span class="num">${fmt.n(c0.lo, 3)}</span>; <span class="num">${fmt.n(c0.hi, 3)}</span>]. Đúng ở <span class="num">${pos}</span>/${pts.length} cấu hình VAR; <span class="num">${mid}</span> mơ hồ; <span class="num">${neg}</span> âm rõ. VAR ${portOk ? "sạch" : "còn tự tương quan"} phần dư (${term("Portmanteau", lang).outerHTML} p = <span class="num">${fmt.p(port)}</span>).`
        : `1σ ≈ <span class="num">${fmt.n(sig * 100, 1)} bp</span>. 95% CI [<span class="num">${fmt.n(c0.lo, 3)}</span>; <span class="num">${fmt.n(c0.hi, 3)}</span>]. Holds in <span class="num">${pos}</span>/${pts.length} VAR specs; <span class="num">${mid}</span> unclear; <span class="num">${neg}</span> clearly negative. Residuals ${portOk ? "clean" : "autocorrelated"} (${term("Portmanteau", lang).outerHTML} p = <span class="num">${fmt.p(port)}</span>).`) : "",
    });
    captionBelow.textContent = vi
      ? `${pos} dương rõ · ${mid} mơ hồ · ${neg} âm rõ (trên ${pts.length} cấu hình)`
      : `${pos} clearly + · ${mid} unclear · ${neg} clearly − (of ${pts.length} specs)`;

    fPath.setTitle(`${VAR[s.impulse]} → ${VAR[s.response]}`);
    fPath.setSub(vi ? `Phản ứng (điểm %) trước cú sốc +${K}σ. Vùng tô: CI 95%.` : `Response (pp) to +${K}σ. Band: 95% CI.`);
    fPath.render((g, { w, h }) => {
      const x = d3.scaleLinear().domain([0, 24]).range([0, w]);
      const y = d3.scaleLinear().domain([d3.min(path, (d) => d.lo), d3.max(path, (d) => d.hi)]).nice().range([h, 0]);
      axisY(g, y, w, { tickFormat: (d) => fmt.n(d, 2), zero: true });
      axisX(g, x, h, { ticks: 8, tickFormat: (d) => d + "M" });
      g.append("path").datum(path).attr("fill", VCOL[s.response]).attr("opacity", 0.18).attr("d", d3.area().x((d) => x(d.h)).y0((d) => y(d.lo)).y1((d) => y(d.hi)));
      g.append("path").datum(path).attr("fill", "none").attr("stroke", VCOL[s.response]).attr("stroke-width", 2.4).attr("d", d3.line().x((d) => x(d.h)).y((d) => y(d.v)));
      g.append("line").attr("x1", x(h0)).attr("x2", x(h0)).attr("y1", 0).attr("y2", h).attr("stroke", "var(--ink)").attr("stroke-dasharray", "3 3");
      if (c0) g.append("circle").attr("cx", x(h0)).attr("cy", y(c0.v)).attr("r", 5).attr("fill", VCOL[s.response]).attr("stroke", "var(--paper)").attr("stroke-width", 1.5);
      g.append("rect").attr("width", w).attr("height", h).attr("fill", "transparent")
        .on("mousemove", (ev) => { const [px] = d3.pointer(ev, g.node()); const p = path[Math.max(0, Math.min(path.length - 1, Math.round(x.invert(px))))]; T.show(`<b>h = ${p.h}M</b><br><span class="m">${fmt.sg(p.v, 3)}</span> [${fmt.n(p.lo, 3)}; ${fmt.n(p.hi, 3)}]`, ev); })
        .on("mouseleave", T.hide);
    });

    // Fed→Fed shock panel
    const shockPath = d3.range(0, 25).map((h) => cellOf(cfg, "fed_funds", "fed_funds", h)).filter(Boolean).map((c) => ({ h: c.h, v: c.irf * K, lo: c.lo * K, hi: c.hi * K }));
    fShock.render((g, { w, h }) => {
      if (!shockPath.length) return;
      const x = d3.scaleLinear().domain([0, 24]).range([0, w]);
      const y = d3.scaleLinear().domain([d3.min(shockPath, (d) => d.lo), d3.max(shockPath, (d) => d.hi)]).nice().range([h, 0]);
      axisY(g, y, w, { tickFormat: (d) => fmt.n(d, 2), zero: true });
      axisX(g, x, h, { ticks: 6, tickFormat: (d) => d + "M" });
      g.append("path").datum(shockPath).attr("fill", VCOL.fed_funds).attr("opacity", 0.15).attr("d", d3.area().x((d) => x(d.h)).y0((d) => y(d.lo)).y1((d) => y(d.hi)));
      g.append("path").datum(shockPath).attr("fill", "none").attr("stroke", VCOL.fed_funds).attr("stroke-width", 2).attr("d", d3.line().x((d) => x(d.h)).y((d) => y(d.v)));
      const s0 = shockPath[0];
      if (s0) g.append("text").attr("class", "lbl mono").attr("x", 4).attr("y", 14).style("fill", "var(--ink-muted)").text(`1σ ≈ ${fmt.n(sig * 100, 1)} bp`);
    });

    fSpec.setTitle(vi ? `Bền qua ${pts.length} cấu hình?` : `Robust across ${pts.length} specs?`);
    fSpec.setSub(vi ? `Mỗi vạch = một cấu hình tại h=${h0}. Xanh: CI>0 · cam: CI<0 · xám: chứa 0.` : `Each tick = one spec at h=${h0}. Green: CI>0 · orange: CI<0 · grey: spans 0.`);
    fSpec.render((g, { w, h }) => {
      const x = d3.scaleLinear().domain([0, pts.length - 1]).range([0, w]);
      const y = d3.scaleLinear().domain([d3.min(pts, (d) => d.lo), d3.max(pts, (d) => d.hi)]).nice().range([h, 0]);
      axisY(g, y, w, { tickFormat: (d) => fmt.n(d, 2), zero: true });
      const col = (q) => (q.lo > 0 ? "var(--status-good)" : q.hi < 0 ? "var(--series-slope)" : "var(--ink-muted)");
      g.selectAll(null).data(pts).join("line").attr("x1", (d, i) => x(i)).attr("x2", (d, i) => x(i)).attr("y1", (d) => y(d.lo)).attr("y2", (d) => y(d.hi)).attr("stroke", col).attr("stroke-width", Math.max(1, w / pts.length * 0.6)).attr("opacity", (d) => (d.clean ? 0.32 : 0.12));
      g.selectAll(null).data(pts).join("circle").attr("cx", (d, i) => x(i)).attr("cy", (d) => y(d.v)).attr("r", (d) => (d.cur ? 5.5 : 1.8)).attr("fill", (d) => (d.cur ? "var(--ink)" : col(d))).attr("stroke", (d) => (d.cur ? "var(--paper)" : "none")).attr("stroke-width", 1.5)
        .on("mousemove", (ev, d) => T.show(`<b>${d.c.preset}</b> · ${d.c.lag_mode}<br><span class="m">${fmt.sg(d.v, 3)}</span> [${fmt.n(d.lo, 3)}; ${fmt.n(d.hi, 3)}]`, ev))
        .on("mouseleave", T.hide);
    });

    fMulti.innerHTML = "";
    fMulti.className = "figs five";
    cfg.order.forEach((r) => {
      const f = figure({ title: `<span style="color:${VCOL[r]}">${VAR[r]}</span>`, height: 140, margin: { l: 34, r: 8, t: 6, b: 22 } });
      f.root.style.opacity = r === s.response ? 1 : 0.78;
      fMulti.append(f.root);
      const pp = d3.range(0, 25).map((hh) => cellOf(cfg, s.impulse, r, hh)).filter(Boolean).map((c) => ({ h: c.h, v: c.irf * K, lo: c.lo * K, hi: c.hi * K }));
      f.render((g, { w, h }) => {
        const x = d3.scaleLinear().domain([0, 24]).range([0, w]);
        const y = d3.scaleLinear().domain([d3.min(pp, (d) => d.lo), d3.max(pp, (d) => d.hi)]).nice().range([h, 0]);
        axisY(g, y, w, { ticks: 3, tickFormat: (d) => fmt.n(d, 2), zero: true });
        axisX(g, x, h, { ticks: 4, tickFormat: (d) => d });
        g.append("path").datum(pp).attr("fill", VCOL[r]).attr("opacity", 0.2).attr("d", d3.area().x((d) => x(d.h)).y0((d) => y(d.lo)).y1((d) => y(d.hi)));
        g.append("path").datum(pp).attr("fill", "none").attr("stroke", VCOL[r]).attr("stroke-width", r === s.response ? 2.4 : 1.6).attr("d", d3.line().x((d) => x(d.h)).y((d) => y(d.v)));
        g.append("rect").attr("width", w).attr("height", h).attr("fill", "transparent").style("cursor", "pointer").on("click", () => { s.response = r; persist(); ctx.onChange({}); });
      });
    });
  }
  update();

  viz.append(explainBox(lang, {
    meaning: vi
      ? `${term("IRF", lang).outerHTML} là đường phản ứng sau một cú sốc chuẩn hoá. ${term("Cholesky", lang).outerHTML} đặt thứ tự nhận diện trong VAR.`
      : `${term("IRF", lang).outerHTML} is the path after a unit shock. ${term("Cholesky", lang).outerHTML} orders identification in the VAR.`,
    confidence: vi
      ? `Tỷ lệ cấu hình dương rõ hiện ~${fmt.pct(ok.filter((c) => { const q = cellOf(c, "fed_funds", "slope", 6); return q && q.lo > 0; }).length / ok.length, 0)} ở Fed→Slope h=6 — dưới 80% nên “Mong manh”.`
      : `Share of clearly positive specs at Fed→Slope h=6 is under 80% → Fragile.`,
    limits: vi
      ? "<ul><li>Cholesky là giả định nhận diện, không chứng minh nhân quả.</li><li>Đổi thứ tự có thể đổi kết quả (xem hình lưới).</li></ul>"
      : "<ul><li>Cholesky is an identifying assumption, not proof of causality.</li><li>Reordering can change results (see the grid).</li></ul>",
  }));
  viz.append(methodDetails(lang, {
    methodHtml: vi
      ? `<p>VAR ước lượng trên mẫu tháng; IRF bootstrap CI 95%. Lạm phát chính: cpi_mom_ann (winsor 2%). Lưới 288 = 6 thứ tự × 6 lag × 4 lạm phát × 2 I(1).</p>`
      : `<p>Monthly VAR; IRF 95% bootstrap bands. Main inflation: cpi_mom_ann (winsor 2%). Grid 288 = 6 orders × 6 lags × 4 inflation × 2 I(1).</p>`,
    reproduceText: reproducePython(state),
  }));
}
