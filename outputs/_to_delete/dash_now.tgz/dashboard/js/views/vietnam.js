import { el, fmt, figure, figs, strip, chips, axisX, axisY, lineChart, parseD, tip, table } from "../ui/kit.js";
import { pageHero } from "../ui/conclusion.js";
import { explainBox, methodDetails, resetLink, term } from "../ui/glossary.js";
import { t } from "../i18n.js";
import { reproducePython } from "../reproduce.js";

export async function mountVietnam(ctx) {
  const { state, data, hero: heroEl, controls, viz, lang, persist, isDefaults, resetToDefaults } = ctx;
  const vi = lang !== "en", vn = data.vn || {}, us = data.factorsMonthly;
  const grid = (vn.lambda_grid || []).map((r) => ({ l: Number(r.lambda ?? r.lam), r: Number(r.rmse_mean ?? r.rmse) })).filter((d) => Number.isFinite(d.l) && Number.isFinite(d.r)).sort((a, b) => a.l - b.l);
  const best = grid.length ? grid.reduce((a, b) => (b.r < a.r ? b : a)) : null;
  const lamVn = vn.lambda_selected ?? best?.l, US = vn.lambda_us ?? 0.7308;
  const atUs = (() => {
    if (!grid.length) return null;
    const i = grid.findIndex((d) => d.l >= US);
    if (i <= 0) return grid[Math.max(0, i)];
    const a = grid[i - 1], b = grid[i], k = (US - a.l) / (b.l - a.l);
    return { l: US, r: a.r + k * (b.r - a.r) };
  })();
  const cor = vn.correlations || {};
  const ar = vn.ar_vs_rw || [];
  const arSig = ar.filter((r) => Number(r.DM_pvalue) < 0.05).length;

  pageHero(heroEl, {
    eyebrow: vi ? "06 · RQ5 · Việt Nam" : "06 · RQ5 · Vietnam",
    title: t(lang, "h2Vn"),
    status: "fragile",
    lang,
    headline: vi
      ? "Ba nhân tố NS mô tả được đường cong VN, nhưng không nên đọc như Mỹ."
      : "NS factors describe Vietnam’s curve, but not like the US.",
    body: vi
      ? `${term("lambda", lang).outerHTML} tối ưu VN <span class="num">${fmt.n(lamVn, 2)}</span> (Mỹ 0.7308), sai số <span class="num">${fmt.n((best?.r ?? NaN) * 100, 1)} bp</span> so với <span class="num">${fmt.n((atUs?.r ?? NaN) * 100, 1)} bp</span> nếu dùng λ Mỹ. Tương quan mức VN–Mỹ: Level <span class="num">${fmt.n(cor.corr_level, 2)}</span>, Slope <span class="num">${fmt.n(cor.corr_slope, 2)}</span>, Curvature <span class="num">${fmt.n(cor.corr_curvature, 2)}</span>; sai phân <span class="num">${fmt.n(cor.corr_level_diff, 2)}</span>/<span class="num">${fmt.n(cor.corr_slope_diff, 2)}</span>/<span class="num">${fmt.n(cor.corr_curvature_diff, 2)}</span>. AR vs RW: <span class="num">${arSig}</span>/${ar.length} ô p&lt;0.05.`
      : `VN best ${term("lambda", lang).outerHTML} <span class="num">${fmt.n(lamVn, 2)}</span> (US 0.7308), RMSE <span class="num">${fmt.n((best?.r ?? NaN) * 100, 1)} bp</span> vs <span class="num">${fmt.n((atUs?.r ?? NaN) * 100, 1)} bp</span> at US λ. Level/Slope/Curv corr <span class="num">${fmt.n(cor.corr_level, 2)}</span>/<span class="num">${fmt.n(cor.corr_slope, 2)}</span>/<span class="num">${fmt.n(cor.corr_curvature, 2)}</span>; diffs <span class="num">${fmt.n(cor.corr_level_diff, 2)}</span>/<span class="num">${fmt.n(cor.corr_slope_diff, 2)}</span>/<span class="num">${fmt.n(cor.corr_curvature_diff, 2)}</span>. AR vs RW: <span class="num">${arSig}</span>/${ar.length} at p&lt;0.05.`,
  });

  viz.append(el("p", { class: "callout", html: vi
    ? "Nguồn Investing.com, giá tham khảo — không phải đường cong chính thức; 7 kỳ hạn 1–15Y."
    : "Investing.com reference quotes — not the official curve; 7 mats 1–15Y." }));

  if (Number.isFinite(cor.corr_level)) {
    viz.append(strip([
      { k: "Level", v: fmt.n(cor.corr_level, 2), d: `${fmt.n(cor.corr_level_diff, 2)} Δ` },
      { k: "Slope", v: fmt.n(cor.corr_slope, 2), d: `${fmt.n(cor.corr_slope_diff, 2)} Δ` },
      { k: "Curvature", v: fmt.n(cor.corr_curvature, 2), d: `${fmt.n(cor.corr_curvature_diff, 2)} Δ` },
      { k: "λ VN", v: fmt.n(lamVn, 2), d: `vs US ${US}` },
    ]));
  }

  let fac = state.vn.factor || "slope";
  const rst = resetLink(lang, !isDefaults(), () => resetToDefaults());
  if (rst) controls.append(rst);

  const fLam = figure({
    title: vi ? "λ nào khớp đường cong VN tốt nhất?" : "Which λ fits Vietnam best?",
    sub: vi ? "RMSE trung bình (bp). Cam: tối ưu VN; xanh: λ Mỹ." : "Mean RMSE (bp). Orange: VN best; blue: US λ.",
    height: 300, margin: { r: 20 },
  });
  const fFac = figure({ title: "​", sub: "", height: 300, margin: { r: 70 } });
  const fHeat = figure({
    title: vi ? "Tỷ lệ ngày đứng giá" : "Share of stale days",
    sub: vi ? "Đậm = nhiều ngày không đổi." : "Darker = more unchanged days.",
    height: 300, margin: { l: 44, r: 10, b: 26 },
  });
  const fAr = el("div");
  viz.append(figs("two", fLam.root, fFac.root), el("div", { style: "height:28px" }), figs("two", fHeat.root, fAr));

  // Factor chips inside the figure area
  const facHost = el("div", { style: "margin:-8px 0 12px" });
  fFac.root.prepend(facHost);
  const facChips = chips({
    label: vi ? "Nhân tố trong hình" : "Factor in chart",
    options: [{ id: "level", label: "Level" }, { id: "slope", label: "Slope" }, { id: "curvature", label: "Curvature" }],
    value: fac,
    onPick: (v) => { fac = v; state.vn.factor = v; persist(); drawFac(); },
  });
  facHost.append(facChips);

  fLam.render((g, { w, h }) => {
    if (!grid.length) return;
    const x = d3.scaleLinear().domain(d3.extent(grid, (d) => d.l)).range([0, w]);
    const y = d3.scaleLinear().domain([d3.min(grid, (d) => d.r * 100) * 0.9, d3.max(grid, (d) => d.r * 100)]).nice().range([h, 0]);
    axisY(g, y, w, { tickFormat: (d) => fmt.n(d, 0), label: "bp" });
    axisX(g, x, h, { ticks: 7, tickFormat: (d) => fmt.n(d, 1) });
    g.append("path").datum(grid).attr("fill", "none").attr("stroke", "var(--ink)").attr("stroke-width", 2).attr("d", d3.line().x((d) => x(d.l)).y((d) => y(d.r * 100)));
    const mk = (p, c, lbl, dy) => {
      g.append("line").attr("x1", x(p.l)).attr("x2", x(p.l)).attr("y1", y(p.r * 100)).attr("y2", h).attr("stroke", c).attr("stroke-dasharray", "3 3");
      g.append("circle").attr("cx", x(p.l)).attr("cy", y(p.r * 100)).attr("r", 5.5).attr("fill", c).attr("stroke", "var(--paper)").attr("stroke-width", 1.5);
      g.append("text").attr("class", "lbl").attr("x", x(p.l) + 9).attr("y", y(p.r * 100) + dy).style("fill", c).text(lbl);
    };
    if (atUs) mk(atUs, "var(--series-level)", `US ${US} · ${fmt.n(atUs.r * 100, 1)} bp`, -10);
    if (best) mk(best, "var(--series-slope)", `VN ${fmt.n(best.l, 2)} · ${fmt.n(best.r * 100, 1)} bp`, 20);
  });

  function drawFac() {
    const vf = (vn.factors_monthly || []).map((r) => ({ x: parseD(r.date), y: r[fac], date: String(r.date).slice(0, 7) }));
    const uMap = new Map(us.dates.map((d, i) => [String(d).slice(0, 7), us.columns[fac][i]]));
    const uf = vf.map((r) => ({ x: r.x, y: uMap.get(r.date), date: r.date })).filter((r) => Number.isFinite(r.y));
    const name = { level: "Level", slope: "Slope", curvature: "Curvature" }[fac];
    fFac.setTitle(vi ? `${name}: VN và Mỹ cùng kỳ` : `${name}: VN vs US`);
    fFac.setSub(vi ? `VN λ=${fmt.n(lamVn, 2)}; Mỹ λ=${US}.` : `VN λ=${fmt.n(lamVn, 2)}; US λ=${US}.`);
    lineChart(fFac, {
      series: [
        { values: vf, color: "var(--series-slope)", label: "VN", width: 2 },
        { values: uf, color: "var(--series-level)", label: vi ? "Mỹ" : "US", width: 2 },
      ],
      xDomain: d3.extent(vf, (d) => d.x), zero: true, yFmt: (d) => fmt.n(d, 0), ylabel: "%",
      hoverRows: vf.map((r) => ({ ...r, us: uMap.get(r.date) })),
      hoverFmt: (r) => `<b>${r.date}</b><br>VN <span class="m">${fmt.n(r.y)}</span><br>US <span class="m">${fmt.n(r.us)}</span>`,
    });
  }
  drawFac();

  const hm = vn.stale_heatmap;
  if (hm?.years?.length) {
    fHeat.render((g, { w, h }) => {
      const x = d3.scaleBand().domain(hm.maturities.map((m) => fmt.mat(m))).range([0, w]).padding(0.05);
      const yb = d3.scaleBand().domain(hm.years).range([0, h]).padding(0.05);
      const c = d3.scaleSequential(d3.interpolateRgb("#f7f6f2", "#b83232")).domain([0, 0.6]);
      const T = tip();
      hm.years.forEach((yr, i) => hm.maturities.forEach((m, j) => {
        const v = hm.values[i][j]; if (v == null) return;
        g.append("rect").attr("x", x(fmt.mat(m))).attr("y", yb(yr)).attr("width", x.bandwidth()).attr("height", yb.bandwidth()).attr("fill", c(Math.min(v, 0.6)))
          .on("mousemove", (ev) => T.show(`<b>${yr} · ${fmt.mat(m)}</b><br>${fmt.pct(v, 0)}`, ev)).on("mouseleave", T.hide);
      }));
      g.append("g").attr("class", "axis").attr("transform", `translate(0,${h})`).call(d3.axisBottom(x).tickSize(0)).select(".domain").remove();
      g.append("g").attr("class", "axis").call(d3.axisLeft(yb).tickSize(0)).select(".domain").remove();
    });
  }

  fAr.append(
    el("h3", { class: "fig-title" }, vi ? "AR vs RW ở VN" : "AR vs RW in Vietnam"),
    el("p", { class: "fig-sub" }, vi ? "21–32 quan sát ngoài mẫu." : "Only 21–32 OOS points."),
    table(
      [
        { h: vi ? "Nhân tố" : "Factor", f: (r) => r.factor },
        { h: "h", f: (r) => r.horizon },
        { h: "n", f: (r) => r.n_obs },
        { h: "AR/RW", f: (r) => fmt.n(r.RMSE_AR / r.RMSE_RW, 3) },
        { h: "p", f: (r) => fmt.p(Number(r.DM_pvalue)) },
      ],
      ar,
    ),
  );

  viz.append(explainBox(lang, {
    meaning: vi
      ? "NS vẫn khớp được với 7 kỳ hạn, nhưng λ và tương quan với Mỹ khác rõ."
      : "NS still fits with 7 mats, but λ and US correlation differ sharply.",
    confidence: vi
      ? "Mẫu AR ngoài mẫu rất ngắn — sức kiểm định thấp."
      : "Very short AR OOS sample — low test power.",
    limits: vi
      ? "<ul><li>Không so sánh mức lãi suất (không ngoại suy τ→0).</li><li>Nhiều ngày đứng giá.</li></ul>"
      : "<ul><li>No level comparison (no τ→0 extrapolation).</li><li>Many stale quote days.</li></ul>",
  }));
  viz.append(methodDetails(lang, {
    methodHtml: vi
      ? `<p>Estimating.com → Investing.com monthly; NS OLS trên 7 kỳ hạn; tương quan với Mỹ tại λ = 0.7308.</p>`
      : `<p>Investing.com monthly; NS OLS on 7 mats; correlations vs US at λ = 0.7308.</p>`,
    reproduceText: reproducePython(state),
  }));
}
