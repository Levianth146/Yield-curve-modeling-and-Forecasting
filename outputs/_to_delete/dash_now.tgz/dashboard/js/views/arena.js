import { selectArLag, runArVsRw, mse } from "../engine/ar.js";
import { dieboldMariano } from "../engine/dm.js";
import { el, fmt, figure, figs, chips, slider, lineChart, parseD, tip } from "../ui/kit.js";
import { pageHero } from "../ui/conclusion.js";
import { explainBox, methodDetails, resetLink, term } from "../ui/glossary.js";
import { t } from "../i18n.js";
import { reproducePython } from "../reproduce.js";

function factors(fm) {
  const c = fm.columns || {};
  return { dates: fm.dates, level: Float64Array.from(c.level), slope: Float64Array.from(c.slope), curvature: Float64Array.from(c.curvature) };
}
function splitIndex(dates, split) {
  const tg = split.slice(0, 7); let idx = -1;
  dates.forEach((d, i) => { if (String(d).slice(0, 7) <= tg) idx = i; });
  return idx;
}
const FN = { level: "Level", slope: "Slope", curvature: "Curvature" };
const HS = [1, 3, 6, 12];

function evalCell(fm, a, factor, h) {
  const series = fm[factor], sp = splitIndex(fm.dates, a.split);
  const p = selectArLag(series, 12, sp, a.lag);
  const oos = runArVsRw(series, sp, p, [h], a.window === "rolling", a.rollingN || 120)[h];
  const act = Float64Array.from(oos.actual), ar = Float64Array.from(oos.arPred), rw = Float64Array.from(oos.rwPred);
  const dm = dieboldMariano(act, ar, rw, h, a.loss === "ae" ? "ae" : "se", a.hln);
  return { p, oos, dm, rmseAr: Math.sqrt(mse(oos.actual, oos.arPred)), rmseRw: Math.sqrt(mse(oos.actual, oos.rwPred)), n: act.length };
}

function heatFill(p) {
  if (p < 0.05) return "#9b2226";
  if (p < 0.10) return "#ca6702";
  return "#adb5bd";
}
function heatText(p) {
  return p < 0.10 ? "#fff" : "#212529";
}

function heatLegend(vi) {
  return el("div", { class: "heat-legend" },
    el("span", {}, el("i", { class: "heat-p05" }), "p < 0.05"),
    el("span", {}, el("i", { class: "heat-p10" }), "0.05 ≤ p < 0.10"),
    el("span", {}, el("i", { class: "heat-pns" }), "p ≥ 0.10"),
  );
}

export async function mountArena(ctx) {
  const { state, data, hero: heroEl, controls, viz, lang, persist, isDefaults, resetToDefaults } = ctx;
  const vi = lang !== "en", a = state.arena, fm = factors(data.factorsMonthly);
  const page = pageHero(heroEl, {
    eyebrow: vi ? "03 · RQ2 · AR vs random walk" : "03 · RQ2 · AR vs random walk",
    title: t(lang, "h2Arena"),
    status: "supported",
    lang,
    headline: "…",
    body: "…",
  });
  const chg = () => { persist(); update(); };

  controls.append(
    chips({ label: vi ? "Nhân tố" : "Factor", options: Object.entries(FN).map(([id, label]) => ({ id, label })), value: a.factor, onPick: (v) => { a.factor = v; chg(); } }),
    chips({ label: vi ? "Chân trời h (tháng)" : "Horizon h (months)", options: HS, value: a.h, mono: true, onPick: (v) => { a.h = Number(v); chg(); } }),
    chips({ label: "Lag IC", options: ["bic", "aic"], value: a.lag, mono: true, onPick: (v) => { a.lag = v; chg(); } }),
    chips({ label: vi ? "Cửa sổ" : "Window", options: [{ id: "expanding", label: "expanding" }, { id: "rolling", label: "rolling 120" }], value: a.window, onPick: (v) => { a.window = v; chg(); } }),
    chips({ label: "Loss", options: [{ id: "se", label: "MSE" }, { id: "ae", label: "MAE" }], value: a.loss, onPick: (v) => { a.loss = v; chg(); } }),
    slider({ label: vi ? "Cuối mẫu huấn luyện" : "Train ends", min: 2005, max: 2022, value: Number(a.split.slice(0, 4)), format: (v) => v + "-12", onInput: (v) => { a.split = `${v}-12-31`; chg(); } }),
  );
  const rst = resetLink(lang, !isDefaults(), () => resetToDefaults());
  if (rst) controls.append(rst);

  const fPath = figure({ title: "​", sub: "", height: 320, margin: { r: 60 } });
  const fCsfe = figure({ title: "​", sub: "", height: 320, margin: { r: 60 } });
  const fHeat = figure({ title: vi ? "12 cấu hình: đâu có ý nghĩa thống kê?" : "12 configs: where is DM significant?", sub: "", height: 190, margin: { l: 96, r: 10, t: 24, b: 26 } });
  const fRat = figure({ title: vi ? "Tỷ lệ RMSE AR / RW" : "RMSE ratio AR / RW", sub: vi ? "Dưới 1 = AR tốt hơn. Chấm đặc = p < 0.05." : "Below 1 = AR better. Filled = p < 0.05.", height: 190, margin: { l: 96, r: 30, t: 20, b: 26 } });
  viz.append(figs("two", fPath.root, fCsfe.root), el("div", { style: "height:28px" }), figs("two", fHeat.root, fRat.root));
  const legendHost = el("div");
  viz.append(legendHost);

  // Yield-by-maturity section
  const yieldSec = el("div", { class: "yield-section", style: "margin-top:36px" });
  viz.append(yieldSec);

  function update() {
    const h = Number(a.h), cur = evalCell(fm, a, a.factor, h);
    const { dm, oos } = cur, pv = dm.p_value;
    const ratio = cur.rmseAr / cur.rmseRw;
    const cells = [];
    for (const f of Object.keys(FN)) for (const hh of HS) {
      const e = f === a.factor && hh === h ? cur : evalCell(fm, a, f, hh);
      cells.push({ f, h: hh, p: e.dm.p_value, dmv: e.dm.DM_stat, ratio: e.rmseAr / e.rmseRw });
    }
    const sig = cells.filter((q) => q.p < 0.05);
    const yRows = data.yieldForecast?.rows || [];
    const ySig = yRows.filter((r) => r.DM_pvalue < 0.05);
    const yRw = ySig.filter((r) => r.DM_stat > 0);

    let headline, status;
    if (pv >= 0.05) {
      status = "supported";
      headline = vi
        ? `AR không đánh bại ${term("RW", lang).outerHTML} khi dự báo ${FN[a.factor]} ${h} tháng tới.`
        : `AR does not beat the ${term("RW", lang).outerHTML} forecasting ${FN[a.factor]} ${h} months ahead.`;
    } else if (dm.DM_stat > 0) {
      status = "fragile";
      headline = vi
        ? `Ở cấu hình này random walk thắng AR có ý nghĩa thống kê.`
        : `In this config the random walk beats AR with statistical significance.`;
    } else {
      status = "fragile";
      headline = vi
        ? `AR thắng random walk — nhưng xem cảnh báo đa kiểm định.`
        : `AR beats the random walk — but see the multiple-testing caveat.`;
    }

    page.setConclusion({
      status,
      headline,
      body: vi
        ? `${term("RMSE", lang).outerHTML} AR <span class="num">${fmt.n(cur.rmseAr, 3)}</span>, RW <span class="num">${fmt.n(cur.rmseRw, 3)}</span>; ${term("DM", lang).outerHTML} p = <span class="num">${fmt.p(pv)}</span>. Trong 12 cấu hình có <span class="num">${sig.length}</span> ô p&lt;0.05 (kỳ vọng ~0.6 do ngẫu nhiên). Theo kỳ hạn: <span class="num">${ySig.length}</span> ô p&lt;0.05 và <span class="num">${yRw.length}</span> trong số đó RW thắng.`
        : `${term("RMSE", lang).outerHTML} AR <span class="num">${fmt.n(cur.rmseAr, 3)}</span>, RW <span class="num">${fmt.n(cur.rmseRw, 3)}</span>; ${term("DM", lang).outerHTML} p = <span class="num">${fmt.p(pv)}</span>. Across 12 configs <span class="num">${sig.length}</span> cells at p&lt;0.05 (~0.6 expected by chance). By maturity: <span class="num">${ySig.length}</span> at p&lt;0.05, of which <span class="num">${yRw.length}</span> favour RW.`,
    });

    const actLbl = t(lang, "actual");
    fPath.setTitle(vi
      ? `Từ ${a.split.slice(0, 4)}, AR RMSE <span class="num">${fmt.n(cur.rmseAr, 2)}</span> so với RW <span class="num">${fmt.n(cur.rmseRw, 2)}</span>`
      : `From ${a.split.slice(0, 4)}, AR RMSE <span class="num">${fmt.n(cur.rmseAr, 2)}</span> vs RW <span class="num">${fmt.n(cur.rmseRw, 2)}</span>`);
    fPath.setSub(vi ? `Đen = ${actLbl}; xanh = RW; cam = AR. Dự báo tại t cho t+${h}.` : `Black = ${actLbl}; blue = RW; orange = AR. Forecast at t for t+${h}.`);

    const dts = oos.idx.map((t) => parseD(fm.dates[t + h]));
    const rows = dts.map((d, i) => ({ x: d, act: oos.actual[i], ar: oos.arPred[i], rw: oos.rwPred[i], date: fm.dates[oos.idx[i] + h] }));
    lineChart(fPath, {
      series: [
        { values: rows.map((r) => ({ x: r.x, y: r.act })), color: "var(--ink)", width: 2, label: actLbl },
        { values: rows.map((r) => ({ x: r.x, y: r.rw })), color: "var(--series-level)", width: 1.3, label: "RW" },
        { values: rows.map((r) => ({ x: r.x, y: r.ar })), color: "var(--series-slope)", width: 1.3, label: "AR" },
      ],
      xDomain: d3.extent(rows, (r) => r.x), zero: true, yFmt: (d) => fmt.n(d, 1), bands: data.recessions.spells, hoverRows: rows,
      hoverFmt: (r) => `<b>${fmt.dateISO(r.date)}</b><br>${actLbl} <span class="m">${fmt.n(r.act)}</span><br>AR <span class="m">${fmt.n(r.ar)}</span><br>RW <span class="m">${fmt.n(r.rw)}</span>`,
    });

    let c = 0;
    const cs = rows.map((r) => { c += (r.rw - r.act) ** 2 - (r.ar - r.act) ** 2; return { x: r.x, y: c, date: r.date }; });
    fCsfe.setTitle(vi ? `Ai dẫn trước? (${term("CSFE", lang).outerHTML})` : `Who is ahead? (${term("CSFE", lang).outerHTML})`);
    fCsfe.setSub(vi ? "Σ(e²_RW − e²_AR). Đi lên = AR thắng." : "Σ(e²_RW − e²_AR). Up = AR ahead.");
    lineChart(fCsfe, {
      series: [{ values: cs, color: c >= 0 ? "var(--series-slope)" : "var(--series-level)", width: 2 }],
      xDomain: d3.extent(cs, (r) => r.x), zero: true, yFmt: (d) => fmt.n(d, 1), bands: data.recessions.spells, hoverRows: cs,
      hoverFmt: (r) => `<b>${fmt.dateISO(r.date)}</b><br>CSFE <span class="m">${fmt.sg(r.y, 3)}</span>`,
      decorate: (g, { x, y, h: hh }) => {
        const l = cs[cs.length - 1];
        g.append("text").attr("class", "lbl mono").attr("x", x(l.x) + 6).attr("y", y(l.y) + 4).style("fill", "var(--ink)").text(fmt.sg(l.y, 2));
        g.append("text").attr("class", "lbl").attr("x", 6).attr("y", 12).style("fill", "var(--ink-muted)").text(vi ? "↑ AR tốt hơn" : "↑ AR better");
        g.append("text").attr("class", "lbl").attr("x", 6).attr("y", hh - 6).style("fill", "var(--ink-muted)").text(vi ? "↓ RW tốt hơn" : "↓ RW better");
      },
    });

    fHeat.setSub(vi
      ? `Màu = mức p (F8). Viền đậm = đang xem. ${sig.length}/12 ô p&lt;0.05.`
      : `Colour = p-band (F8). Outline = current. ${sig.length}/12 at p&lt;0.05.`);
    const T = tip();
    fHeat.render((g, { w, h: hh }) => {
      const x = d3.scaleBand().domain(HS).range([0, w]).padding(0.06);
      const yb = d3.scaleBand().domain(Object.keys(FN)).range([0, hh]).padding(0.08);
      g.append("g").attr("class", "axis").attr("transform", `translate(0,${hh})`).call(d3.axisBottom(x).tickFormat((d) => "h=" + d).tickSize(0)).select(".domain").remove();
      Object.keys(FN).forEach((f) => g.append("text").attr("x", -10).attr("y", yb(f) + yb.bandwidth() / 2 + 4).attr("text-anchor", "end").style("font-size", "12px").style("fill", "var(--ink)").text(FN[f]));
      const grp = g.selectAll(null).data(cells).join("g").style("cursor", "pointer")
        .on("click", (ev, d) => { a.factor = d.f; a.h = d.h; persist(); ctx.onChange({}); })
        .on("mousemove", (ev, d) => T.show(`<b>${FN[d.f]} h=${d.h}</b><br>p <span class="m">${fmt.p(d.p)}</span> · DM <span class="m">${fmt.sg(d.dmv, 2)}</span><br>RMSE AR/RW <span class="m">${fmt.n(d.ratio, 3)}</span>`, ev))
        .on("mouseleave", T.hide);
      grp.append("rect").attr("x", (d) => x(d.h)).attr("y", (d) => yb(d.f)).attr("width", x.bandwidth()).attr("height", yb.bandwidth())
        .attr("fill", (d) => heatFill(d.p))
        .attr("stroke", (d) => (d.f === a.factor && d.h === h ? "var(--ink)" : "none")).attr("stroke-width", 2);
      grp.append("text").attr("class", "mono").attr("x", (d) => x(d.h) + x.bandwidth() / 2).attr("y", (d) => yb(d.f) + yb.bandwidth() / 2 + 4)
        .attr("text-anchor", "middle").style("font-size", "11.5px").style("fill", (d) => heatText(d.p))
        .text((d) => fmt.p(d.p));
    });
    legendHost.replaceChildren(heatLegend(vi));

    fRat.render((g, { w, h: hh }) => {
      const x = d3.scaleLinear().domain([Math.min(0.85, d3.min(cells, (q) => q.ratio) - 0.03), Math.max(1.15, d3.max(cells, (q) => q.ratio) + 0.03)]).range([0, w]);
      const yb = d3.scaleBand().domain(Object.keys(FN)).range([0, hh]).padding(0.3);
      g.append("line").attr("class", "zero-line").attr("x1", x(1)).attr("x2", x(1)).attr("y1", 0).attr("y2", hh);
      g.append("g").attr("class", "axis").attr("transform", `translate(0,${hh})`).call(d3.axisBottom(x).ticks(5).tickSizeOuter(0));
      Object.keys(FN).forEach((f) => { g.append("text").attr("x", -10).attr("y", yb(f) + yb.bandwidth() / 2 + 4).attr("text-anchor", "end").style("font-size", "12px").style("fill", "var(--ink)").text(FN[f]); });
      const cc = { 1: "#9aa0a6", 3: "#6a7f9a", 6: "#3a68a8", 12: "#2a78d6" };
      g.selectAll(null).data(cells).join("circle")
        .attr("cx", (d) => x(d.ratio)).attr("cy", (d) => yb(d.f) + yb.bandwidth() / 2)
        .attr("r", (d) => 3 + HS.indexOf(d.h) * 1.4)
        .attr("fill", (d) => (d.p < 0.05 ? cc[d.h] : "var(--paper)"))
        .attr("stroke", (d) => cc[d.h]).attr("stroke-width", 1.6)
        .on("mousemove", (ev, d) => T.show(`<b>${FN[d.f]} h=${d.h}</b> · AR/RW <span class="m">${fmt.n(d.ratio, 3)}</span> · p <span class="m">${fmt.p(d.p)}</span>`, ev))
        .on("mouseleave", T.hide);
      g.append("text").attr("class", "lbl").attr("x", x(1) - 6).attr("y", 8).attr("text-anchor", "end").style("fill", "var(--ink-muted)").text(vi ? "← AR tốt hơn" : "← AR better");
      g.append("text").attr("class", "lbl").attr("x", x(1) + 6).attr("y", 8).style("fill", "var(--ink-muted)").text(vi ? "RW tốt hơn →" : "RW better →");
    });

    // Yield maturity heatmap
    yieldSec.innerHTML = "";
    yieldSec.append(el("h3", { class: "fig-title" }, vi ? "Theo từng kỳ hạn" : "By maturity"));
    yieldSec.append(el("p", { class: "fig-sub" }, vi
      ? "Ô = tỷ lệ RMSE AR/RW; màu = mức p DM; p trong tooltip."
      : "Cell = RMSE AR/RW ratio; colour = DM p-band; p in tooltip."));
    if (!yRows.length) {
      yieldSec.append(el("p", { class: "callout" }, vi ? "Chưa có yield_forecast_golden.json." : "yield_forecast_golden.json missing."));
    } else {
      const mats = [...new Map(yRows.map((r) => [r.tau_years, r.maturity])).entries()].sort((a, b) => a[0] - b[0]);
      const hs = [...new Set(yRows.map((r) => r.horizon))].sort((a, b) => a - b);
      const cell = (m, hh) => yRows.find((r) => r.maturity === m && r.horizon === hh);
      const fmtM = (m) => (/MO$/.test(m) ? m.replace("DGS", "").replace("MO", "M") : m.replace("DGS", "") + "Y");
      const fY = figure({ title: "", height: 60 + mats.length * 34, margin: { l: 54, r: 10, t: 26, b: 6 } });
      yieldSec.append(fY.root, heatLegend(vi));
      fY.render((g, { w, h }) => {
        const x = d3.scaleBand().domain(hs).range([0, w]).padding(0.05);
        const y = d3.scaleBand().domain(mats.map((m) => m[1])).range([0, h]).padding(0.08);
        g.append("g").attr("class", "axis").call(d3.axisTop(x).tickFormat((d) => "h=" + d).tickSize(0)).select(".domain").remove();
        g.append("g").attr("class", "axis").call(d3.axisLeft(y).tickFormat(fmtM).tickSize(0)).select(".domain").remove();
        for (const [, m] of mats) for (const hh of hs) {
          const r = cell(m, hh); if (!r) continue;
          const ratio = r.RMSE_AR / r.RMSE_RW;
          const grp = g.append("g")
            .on("mousemove", (ev) => T.show(`<b>${fmtM(m)} h=${hh}</b><br>AR/RW <span class="m">${fmt.n(ratio, 3)}</span> · p <span class="m">${fmt.p(r.DM_pvalue)}</span>`, ev))
            .on("mouseleave", T.hide);
          grp.append("rect").attr("x", x(hh)).attr("y", y(m)).attr("width", x.bandwidth()).attr("height", y.bandwidth())
            .attr("fill", heatFill(r.DM_pvalue))
            .attr("stroke", r.DM_pvalue < 0.05 ? "var(--ink)" : "none").attr("stroke-width", 2);
          grp.append("text").attr("class", "mono").attr("x", x(hh) + x.bandwidth() / 2).attr("y", y(m) + y.bandwidth() / 2 + 4)
            .attr("text-anchor", "middle").style("font-size", "11px").style("fill", heatText(r.DM_pvalue))
            .text(fmt.n(ratio, 2));
        }
      });
    }
  }
  update();

  viz.append(explainBox(lang, {
    meaning: vi
      ? `${term("RW", lang).outerHTML} = dự báo tháng sau bằng đúng giá trị hôm nay. Nếu mô hình phức tạp không thắng được nó, mô hình đó chưa thêm thông tin.`
      : `${term("RW", lang).outerHTML} = next month equals today. If a richer model cannot beat it, it adds no information.`,
    confidence: vi
      ? "Một điểm chia mẫu; 12 phép thử không hiệu chỉnh đa kiểm định (Bonferroni p&lt;0.0042)."
      : "Single split; 12 tests without multiple-testing correction (Bonferroni p&lt;0.0042).",
    limits: vi
      ? "<ul><li>Sai số điểm ≠ giá trị kinh tế.</li><li>Đổi thanh cuối mẫu huấn luyện để thấy độ nhạy.</li></ul>"
      : "<ul><li>Point forecast error ≠ economic value.</li><li>Move the train-end slider to see sensitivity.</li></ul>",
  }));
  viz.append(methodDetails(lang, {
    methodHtml: vi
      ? `<p>AR lag chọn bằng ${a.lag.toUpperCase()}; cửa sổ ${a.window}; loss ${a.loss}; ${term("DM", lang).outerHTML} với HLN khi h&gt;1. Split chính: train ≤ ${a.split.slice(0, 7)}.</p>`
      : `<p>AR lag by ${a.lag.toUpperCase()}; window ${a.window}; loss ${a.loss}; ${term("DM", lang).outerHTML} with HLN when h&gt;1. Main split: train ≤ ${a.split.slice(0, 7)}.</p>`,
    reproduceText: reproducePython(state),
  }));
}
