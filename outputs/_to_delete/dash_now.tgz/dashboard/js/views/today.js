import { fitNsDay, NS_LAMBDA_DEFAULT } from "../engine/ns.js";
import { predictProbit } from "../engine/probit.js";
import { el, fmt, figure, figs, strip, axisY, endLabels, lineChart, tip } from "../ui/kit.js";
import { pageHero } from "../ui/conclusion.js";
import { explainBox, methodDetails, resetLink } from "../ui/glossary.js";
import { t } from "../i18n.js";
import { reproducePython } from "../reproduce.js";

function nearestIdx(dates, iso) {
  let b = 0;
  for (let i = 0; i < dates.length; i++) if (dates[i] <= iso) b = i;
  return b;
}
function addMonths(iso, m) {
  const d = new Date(iso + "T00:00:00Z");
  d.setUTCMonth(d.getUTCMonth() + m);
  return d.toISOString().slice(0, 10);
}

export async function mountToday(ctx) {
  const { data, hero: heroEl, viz, controls, lang, state, isDefaults, resetToDefaults } = ctx;
  const vi = lang !== "en";
  const y = data.yields, n = y.dates.length, last = n - 1, today = y.dates[last];
  const mi = (m) => y.maturities.findIndex((x) => Math.abs(x - m) < 1e-6);
  const i10 = mi(10), i2 = mi(2), i3m = mi(0.25);
  const nsIdx = y.maturities.map((m, i) => (Math.abs(m - 1 / 12) > 1e-6 ? i : -1)).filter((i) => i >= 0);
  const tau = nsIdx.map((i) => y.maturities[i]);
  const rowAt = (i) => nsIdx.map((j) => y.yields[j][i]);
  const idx1m = nearestIdx(y.dates, addMonths(today, -1));
  const idx1y = nearestIdx(y.dates, addMonths(today, -12));
  const s102 = y.yields[i10][last] - y.yields[i2][last];
  const s103 = y.yields[i10][last] - y.yields[i3m][last];
  const g = data.probitGolden?.spread_10y2y_fixed;
  const pRec = g ? predictProbit(g.coef_const, g.coef, s102) : NaN;

  let lastInv = null;
  for (let i = last; i >= 0; i--) if (y.yields[i10][i] - y.yields[i2][i] < 0) { lastInv = y.dates[i]; break; }
  let lastInv3 = null;
  for (let i = last; i >= 0; i--) if (y.yields[i10][i] - y.yields[i3m][i] < 0) { lastInv3 = y.dates[i]; break; }

  const shape = s102 < -0.05 ? (vi ? "đảo ngược" : "inverted")
    : Math.abs(s102) < 0.15 ? (vi ? "phẳng" : "flat")
    : (vi ? "dốc dương" : "upward-sloping");

  pageHero(heroEl, {
    eyebrow: vi ? `01 · Hôm nay · ${fmt.dateText(today)}` : `01 · Today · ${fmt.dateISO(today)}`,
    title: t(lang, "h2Today"),
    status: "fragile",
    lang,
    headline: vi
      ? `Đường cong đang ${shape}: 10Y−2Y = <span class="num">${fmt.sg(s102)}</span> điểm %, 10Y−3M = <span class="num">${fmt.sg(s103)}</span>.`
      : `The curve is ${shape}: 10Y−2Y = <span class="num">${fmt.sg(s102)}</span> pp, 10Y−3M = <span class="num">${fmt.sg(s103)}</span>.`,
    body: vi
      ? `Ngưỡng đảo ngược là 0. Lần gần nhất 10Y−2Y âm là <span class="num">${lastInv ? fmt.dateText(lastInv) : "—"}</span>; 10Y−3M âm là <span class="num">${lastInv3 ? fmt.dateText(lastInv3) : "—"}</span>. Probit của đề án cho xác suất suy thoái trong 12 tháng tới <span class="num">${fmt.pct(pRec)}</span> — đọc như thứ hạng rủi ro, không phải xác suất chuẩn (BSS âm, xem mục Suy thoái).`
      : `Inversion threshold is 0. Last negative 10Y−2Y: <span class="num">${lastInv ? fmt.dateISO(lastInv) : "—"}</span>; 10Y−3M: <span class="num">${lastInv3 ? fmt.dateISO(lastInv3) : "—"}</span>. Project probit puts 12-month recession risk at <span class="num">${fmt.pct(pRec)}</span> — a ranking signal, not a calibrated probability (negative BSS; see Recession).`,
  });

  const reset = resetLink(lang, !isDefaults(), () => resetToDefaults());
  if (reset) controls.append(reset);

  viz.append(strip([
    { k: "10Y", v: fmt.n(y.yields[i10][last]) + "%", d: vi ? `${fmt.sg(y.yields[i10][last] - y.yields[i10][idx1m])} điểm % vs 1 tháng` : `${fmt.sg(y.yields[i10][last] - y.yields[i10][idx1m])} pp vs 1M` },
    { k: "2Y", v: fmt.n(y.yields[i2][last]) + "%", d: vi ? `${fmt.sg(y.yields[i2][last] - y.yields[i2][idx1m])} điểm % vs 1 tháng` : `${fmt.sg(y.yields[i2][last] - y.yields[i2][idx1m])} pp vs 1M` },
    { k: "10Y − 2Y", v: fmt.sg(s102), cls: s102 < 0 ? "neg" : "", d: vi ? `Đảo ngược gần nhất: ${lastInv ? fmt.dateText(lastInv) : "—"}` : `Last inverted: ${lastInv || "—"}` },
    { k: "10Y − 3M", v: fmt.sg(s103), cls: s103 < 0 ? "neg" : "", d: vi ? `Đảo ngược gần nhất: ${lastInv3 ? fmt.dateText(lastInv3) : "—"}` : `Last inverted: ${lastInv3 || "—"}` },
  ]));

  const f1 = figure({
    title: vi ? "Đường cong hôm nay so với 1 tháng và 1 năm trước" : "Today vs 1 month and 1 year ago",
    sub: vi ? "Đường liền: Nelson–Siegel khớp; chấm: quan sát." : "Solid: Nelson–Siegel fit; dots: observed.",
    height: 320, margin: { r: 78 },
  });
  const snaps = [
    { i: idx1y, c: "var(--ink-muted)", lbl: vi ? "1 năm trước" : "1Y ago", dash: "3 3" },
    { i: idx1m, c: "var(--series-level)", lbl: vi ? "1 tháng trước" : "1M ago" },
    { i: last, c: "var(--series-slope)", lbl: vi ? "Hôm nay" : "Today", w: 2.6 },
  ];
  f1.render((gg, { w, h }) => {
    const x = d3.scaleSqrt().domain([0.25, 30]).range([0, w]);
    const all = snaps.flatMap((s) => rowAt(s.i)).filter(Number.isFinite);
    const yy = d3.scaleLinear().domain([Math.min(...all) - 0.15, Math.max(...all) + 0.15]).nice().range([h, 0]);
    axisY(gg, yy, w, { tickFormat: (d) => fmt.n(d, 1) });
    gg.append("g").attr("class", "axis").attr("transform", `translate(0,${h})`).call(d3.axisBottom(x).tickValues([0.25, 1, 2, 5, 10, 20, 30]).tickFormat(fmt.mat).tickSizeOuter(0));
    const grid = d3.range(0.25, 30.01, 0.25);
    const labs = [];
    for (const s of snaps) {
      const r = rowAt(s.i), f = fitNsDay(tau, r, NS_LAMBDA_DEFAULT);
      if (f) gg.append("path").datum(grid).attr("fill", "none").attr("stroke", s.c).attr("stroke-width", s.w || 1.5).attr("stroke-dasharray", s.dash || null).attr("d", d3.line().x((t) => x(t)).y((t) => yy(f.fitted(t))));
      gg.selectAll(null).data(tau.map((t, k) => [t, r[k]]).filter((d) => Number.isFinite(d[1]))).join("circle").attr("cx", (d) => x(d[0])).attr("cy", (d) => yy(d[1])).attr("r", s.w ? 3.2 : 2).attr("fill", s.c).attr("stroke", "var(--paper)").attr("stroke-width", 1);
      const lastPt = r[r.length - 1];
      labs.push({ x: x(30), y: yy(lastPt), text: s.lbl, color: s.c });
    }
    endLabels(gg, labs);
    const T = tip();
    gg.append("rect").attr("width", w).attr("height", h).attr("fill", "transparent").on("mousemove", (ev) => {
      const [px] = d3.pointer(ev, gg.node()); const t0 = x.invert(px); let k = 0, bd = 1e9;
      tau.forEach((t, q) => { if (Math.abs(t - t0) < bd) { bd = Math.abs(t - t0); k = q; } });
      T.show(`<b>${fmt.mat(tau[k])}</b><br>` + snaps.map((s) => `${s.lbl}: <span class="m">${fmt.n(rowAt(s.i)[k], 2)}%</span>`).join("<br>"), ev);
    }).on("mouseleave", T.hide);
  });

  const rows = [];
  for (let i = 0; i < n; i++) {
    const v = y.yields[i10][i] - y.yields[i2][i];
    if (Number.isFinite(v)) rows.push({ x: new Date(y.dates[i]), y: v, d: y.dates[i] });
  }
  const f2 = figure({
    title: vi ? "10Y − 2Y từ 2000, kèm suy thoái NBER" : "10Y − 2Y since 2000 with NBER recessions",
    sub: vi ? "Vùng xám: suy thoái. Dưới 0 = đảo ngược." : "Shaded: recessions. Below zero = inversion.",
    height: 320,
  });
  lineChart(f2, {
    series: [{ values: rows, color: "var(--series-slope)", width: 1.3 }],
    xDomain: d3.extent(rows, (d) => d.x), bands: data.recessions.spells, zero: true,
    yFmt: (d) => fmt.n(d, 1), ylabel: vi ? "điểm %" : "pp",
    hoverRows: rows, hoverFmt: (r) => `<b>${fmt.dateISO(r.d)}</b><br>10Y−2Y <span class="m">${fmt.sg(r.y)}</span>`,
    decorate: (gg, { x, y: sy }) => {
      const lr = rows[rows.length - 1];
      gg.append("circle").attr("cx", x(lr.x)).attr("cy", sy(lr.y)).attr("r", 4).attr("fill", "var(--series-slope)").attr("stroke", "var(--paper)").attr("stroke-width", 1.5);
    },
  });
  viz.append(figs("two", f1.root, f2.root));

  viz.append(explainBox(lang, {
    meaning: vi
      ? "Dốc dương: dài hạn cao hơn ngắn hạn. Phẳng: chênh lệch gần 0. Đảo ngược: dài hạn thấp hơn ngắn hạn — thường gắn với kỳ vọng nới lỏng / suy thoái."
      : "Upward: long rates above short. Flat: near-zero spread. Inverted: long below short — often tied to easing / recession expectations.",
    confidence: vi
      ? `Xác suất probit <span class="num">${fmt.pct(pRec)}</span> chỉ là chỉ báo xếp hạng — xem trang Suy thoái cho AUC/BSS.`
      : `Probit probability <span class="num">${fmt.pct(pRec)}</span> is a ranking signal — see Recession for AUC/BSS.`,
    limits: vi
      ? "<ul><li>Trang này không dự báo lợi suất.</li><li>Đường liền là khớp Nelson–Siegel; chấm là quan sát.</li><li>Probit BSS âm nên mức % không phải xác suất chuẩn.</li></ul>"
      : "<ul><li>This page does not forecast yields.</li><li>Solid line is Nelson–Siegel fit; dots are observed.</li><li>Negative BSS means the % level is not a calibrated probability.</li></ul>",
  }));

  viz.append(methodDetails(lang, {
    methodHtml: vi
      ? `<p>Nelson–Siegel λ = 0.7308 trên 10 kỳ hạn (bỏ DGS1MO). Spread 10Y−2Y / 10Y−3M từ chuỗi FRED hàng ngày. Probit: Φ(β₀+β₁·spread) với hệ số cố định từ mẫu huấn luyện đề án.</p>`
      : `<p>Nelson–Siegel λ = 0.7308 on 10 maturities (drop DGS1MO). Spreads from daily FRED. Probit: Φ(β₀+β₁·spread) with fixed coefficients from the project training sample.</p>`,
    reproduceText: reproducePython(state),
  }));
}
