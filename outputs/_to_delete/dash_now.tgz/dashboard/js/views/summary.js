import { evaluateClaims } from "../engine/claims.js";
import { splitProbitRows, evaluateProbitOos } from "../engine/probit.js";
import { REPORT } from "../reportFacts.js";
import { el, fmt } from "../ui/kit.js";
import { pageHero } from "../ui/conclusion.js";
import { t } from "../i18n.js";

const ST = {
  supported: ["✓", "claim-supported", "statusSupported"],
  fragile: ["!", "claim-fragile", "statusFragile"],
  notSupported: ["×", "claim-not", "statusNotSupported"],
};

function svgBox(w = 480, h = 64) {
  return d3.create("svg").attr("viewBox", `0 0 ${w} ${h}`).attr("width", "100%").style("display", "block");
}
function pStrip(ps, thr) {
  const s = svgBox(), x = d3.scaleLinear().domain([0, 1]).range([8, 472]);
  s.append("line").attr("x1", 8).attr("x2", 472).attr("y1", 40).attr("y2", 40).attr("stroke", "var(--ink-muted)");
  s.append("line").attr("x1", x(thr)).attr("x2", x(thr)).attr("y1", 18).attr("y2", 50).attr("stroke", "var(--status-serious)").attr("stroke-dasharray", "2 2");
  ps.forEach((p, i) => s.append("circle").attr("cx", x(Math.min(1, p))).attr("cy", 40 + ((i % 3) - 1) * 7).attr("r", 4.5).attr("fill", p < thr ? "var(--status-serious)" : "var(--ink)").attr("opacity", 0.8).attr("stroke", "var(--paper)"));
  return s.node();
}
function barsThr(vals, labels, thr, max = 1) {
  const s = svgBox(480, 24 * vals.length + 14), x = d3.scaleLinear().domain([0, max]).range([54, 472]);
  vals.forEach((v, i) => {
    s.append("text").attr("x", 0).attr("y", 20 + i * 24).attr("class", "lbl mono").style("fill", "var(--ink-secondary)").style("stroke", "none").text(labels[i]);
    s.append("rect").attr("x", 54).attr("y", 8 + i * 24).attr("height", 16).attr("width", x(v) - 54).attr("fill", v < thr ? "var(--series-slope)" : "var(--series-level)").attr("opacity", 0.85);
    s.append("text").attr("x", x(v) + 5).attr("y", 20 + i * 24).attr("class", "lbl mono").style("fill", "var(--ink)").style("stroke", "none").text(fmt.n(v, 2));
  });
  s.append("line").attr("x1", x(thr)).attr("x2", x(thr)).attr("y1", 2).attr("y2", 24 * vals.length + 10).attr("stroke", "var(--ink)").attr("stroke-dasharray", "3 2");
  return s.node();
}
function auc_bss(auc, sk) {
  const s = svgBox(480, 84), xa = d3.scaleLinear().domain([0.5, 1]).range([70, 470]), xb = d3.scaleLinear().domain([-0.3, 0.3]).range([70, 470]);
  s.append("text").attr("x", 0).attr("y", 24).attr("class", "lbl mono").style("stroke", "none").style("fill", "var(--ink-secondary)").text("AUC");
  s.append("rect").attr("x", 70).attr("y", 10).attr("height", 18).attr("width", xa(auc) - 70).attr("fill", "var(--series-level)").attr("opacity", 0.85);
  s.append("text").attr("x", xa(auc) + 5).attr("y", 24).attr("class", "lbl mono").style("stroke", "none").style("fill", "var(--ink)").text(fmt.n(auc, 3));
  s.append("text").attr("x", 0).attr("y", 66).attr("class", "lbl mono").style("stroke", "none").style("fill", "var(--ink-secondary)").text("BSS");
  s.append("rect").attr("x", Math.min(xb(0), xb(sk))).attr("y", 52).attr("height", 18).attr("width", Math.abs(xb(sk) - xb(0))).attr("fill", sk < 0 ? "var(--series-slope)" : "var(--status-good)").attr("opacity", 0.85);
  s.append("line").attr("x1", xb(0)).attr("x2", xb(0)).attr("y1", 44).attr("y2", 78).attr("stroke", "var(--ink)");
  s.append("text").attr("x", sk < 0 ? xb(sk) - 5 : xb(sk) + 5).attr("text-anchor", sk < 0 ? "end" : "start").attr("y", 66).attr("class", "lbl mono").style("stroke", "none").style("fill", "var(--ink)").text(fmt.sgpct(sk));
  return s.node();
}
function splitBar(parts) {
  const s = svgBox(480, 56), tot = d3.sum(parts, (p) => p.n); let x0 = 0;
  parts.forEach((p) => {
    const w = (p.n / tot) * 284;
    s.append("rect").attr("x", 8 + x0).attr("y", 10).attr("width", w).attr("height", 22).attr("fill", p.c);
    if (w > 26) s.append("text").attr("x", 8 + x0 + 6).attr("y", 25).attr("class", "lbl mono").style("stroke", "none").style("fill", "#fff").text(p.n);
    x0 += w;
  });
  parts.forEach((p, i) => s.append("text").attr("x", 8 + i * 150).attr("y", 50).attr("class", "lbl mono").style("stroke", "none").style("fill", "var(--ink-secondary)").text(p.l));
  return s.node();
}

const LINKS = { C1: "curve", C2: "arena", C3: "irf", C4: "probit", C5: "vietnam" };

export async function mountSummary(ctx) {
  const { data, hero: heroEl, viz, lang, state } = ctx;
  const vi = lang !== "en";
  const main = data.arGolden?.main || [], slope12 = main.find((r) => r.factor === "slope" && Number(r.horizon) === 12);
  const arP = main.map((r) => Number(r.DM_pvalue)).filter(Number.isFinite);
  const sigShare = arP.filter((p) => p < 0.05).length / (arP.length || 1);
  const grid = await data.loadIrf();
  const cfgs = grid?.configs?.filter((c) => c.irf && !c.error) || [];
  const at = (c, h) => c.irf.find((r) => r.impulse === "fed_funds" && r.response === "slope" && r.h === h);
  const def = cfgs.find((c) => c.default) || cfgs[0];
  const fedCells = def ? [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((h) => at(def, h)).filter(Boolean) : [];
  const g6 = cfgs.map((c) => at(c, 6)).filter(Boolean);
  const pos = g6.filter((q) => q.lo > 0).length, neg = g6.filter((q) => q.hi < 0).length;
  const { train, test } = splitProbitRows(data.probitDataset.rows, "1998-12", "2000-01", true);
  const pm = evaluateProbitOos(train, test);
  const vnRows = data.vn?.ar_vs_rw || [];
  const results = {
    factorCorr: Math.max(REPORT.nls.corrLevel, REPORT.nls.corrSlope, REPORT.nls.corrCurv),
    dmP: slope12?.DM_pvalue,
    specShareSig: sigShare,
    fedSlopeCells: fedCells,
    irfSharePos: cfgs.length ? pos / cfgs.length : null,
    auc: pm.auc,
    bss: pm.bss,
    vnArRows: vnRows,
  };
  // status only — do not render registry text (F6)
  const items = evaluateClaims(lang, results).map((i) => ({ id: i.id, status: i.status }));
  const by = Object.fromEntries(items.map((i) => [i.id, i]));
  const nSup = items.filter((i) => i.status === "supported").length;
  const nFrag = items.filter((i) => i.status === "fragile").length;

  pageHero(heroEl, {
    eyebrow: vi ? "07 · Tổng kết" : "07 · Summary",
    title: t(lang, "h2Summary"),
    status: nSup >= 3 ? "supported" : "fragile",
    lang,
    headline: vi
      ? `<span class="num">${nSup}</span>/5 kết luận đứng vững, <span class="num">${nFrag}</span> mong manh.`
      : `<span class="num">${nSup}</span>/5 claims stand, <span class="num">${nFrag}</span> fragile.`,
    body: vi
      ? "Mỗi thẻ tính lại từ dữ liệu dashboard. “Mong manh” = đúng ở cấu hình đề án nhưng yếu khi đổi đặc tả lân cận."
      : "Each card is recomputed from dashboard data. “Fragile” = holds at the report spec but weakens nearby.",
  });

  const copyBtn = el("button", {
    type: "button",
    class: "btn-copy",
    onclick: () => {
      const url = location.href;
      navigator.clipboard?.writeText(url).then(() => {
        copyBtn.textContent = t(lang, "copied");
        setTimeout(() => { copyBtn.textContent = t(lang, "copyPermalink"); }, 1500);
      });
    },
  }, t(lang, "copyPermalink"));
  viz.append(el("div", { style: "margin-bottom:18px" }, copyBtn));

  const titles = {
    C1: vi ? "NLS fit khít hơn nhưng nhân tố bất ổn" : "NLS fits tighter but factors are unstable",
    C2: vi ? "AR không thắng random walk" : "AR does not beat the random walk",
    C3: vi ? "Cú sốc Fed nâng Slope" : "A Fed shock lifts Slope",
    C4: vi ? "Probit: xếp hạng tốt, hiệu chuẩn kém" : "Probit: ranks well, calibrates poorly",
    C5: vi ? "Việt Nam: AR cũng không thắng RW" : "Vietnam: AR does not beat RW either",
  };
  const cards = [
    { id: "C1", viz: barsThr([REPORT.nls.corrLevel, REPORT.nls.corrSlope, REPORT.nls.corrCurv], ["Level", "Slope", "Curv."], 0.6), cap: vi ? `Số báo cáo, ${REPORT.nls.n} ngày. Nét đứt = 0.6.` : `Report numbers, ${REPORT.nls.n} days. Dashed = 0.6.` },
    { id: "C2", viz: pStrip(arP, 0.05), cap: vi ? `Slope h=12: p = ${fmt.p(slope12?.DM_pvalue)}. ${arP.filter((p) => p < 0.05).length}/12 ô p&lt;0.05.` : `Slope h=12 p = ${fmt.p(slope12?.DM_pvalue)}.` },
    { id: "C3", viz: splitBar([{ n: pos, c: "var(--status-good)", l: vi ? "dương rõ" : "positive" }, { n: g6.length - pos - neg, c: "var(--ink-muted)", l: vi ? "mơ hồ" : "unclear" }, { n: neg, c: "var(--series-slope)", l: vi ? "âm rõ" : "negative" }]), cap: vi ? `Fed→Slope h=6: ${fmt.n(at(def, 6)?.irf, 3)} [${fmt.n(at(def, 6)?.lo, 3)}; ${fmt.n(at(def, 6)?.hi, 3)}].` : `Fed→Slope h=6 across ${g6.length} specs.` },
    { id: "C4", viz: auc_bss(pm.auc, pm.bss), cap: vi ? `AUC ${fmt.n(pm.auc, 3)} · BSS ${fmt.sgpct(pm.bss)}.` : `AUC ${fmt.n(pm.auc, 3)}; BSS ${fmt.sgpct(pm.bss)}.` },
    { id: "C5", viz: pStrip(vnRows.map((r) => Number(r.DM_pvalue)), 0.05), cap: vi ? `${vnRows.length} ô, 21–32 quan sát OOS.` : `${vnRows.length} cells, 21–32 OOS points.` },
  ];

  const grid2 = el("div", { class: "claim-grid" });
  for (const c of cards) {
    const it = by[c.id], [ic, cls, sk] = ST[it.status];
    grid2.append(el("section", { class: "claim-card" },
      el("div", { class: "st " + cls }, el("i", {}, ic), `${c.id} · ${t(lang, sk)}`),
      el("h3", { class: "fig-title", style: "margin-top:6px;font-size:1.05rem" }, titles[c.id]),
      c.viz,
      el("p", { class: "ev", html: c.cap }),
      el("a", { href: `#/${LINKS[c.id]}` }, vi ? "Xem trang chi tiết →" : "Open detail →"),
    ));
  }
  viz.append(grid2);
}
